import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shamsi_date/shamsi_date.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const HamrahYarApp());
}

const ink = Color(0xFF182B3A);
const teal = Color(0xFF168C83);
const canvas = Color(0xFFF5F7F8);

class HamrahYarApp extends StatelessWidget {
  const HamrahYarApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'همراه‌یار',
    locale: const Locale('fa'),
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: canvas,
      colorScheme: ColorScheme.fromSeed(seedColor: teal, brightness: Brightness.light),
      fontFamily: 'Roboto',
      appBarTheme: const AppBarTheme(backgroundColor: canvas, foregroundColor: ink, elevation: 0, centerTitle: false),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 14),
      ),
    ),
    home: const Directionality(textDirection: TextDirection.rtl, child: HomeShell()),
  );
}

String jalali(DateTime d) {
  final j = Jalali.fromDateTime(d);
  return '${j.year}/${j.month.toString().padLeft(2,'0')}/${j.day.toString().padLeft(2,'0')}';
}

class Entry {
  Entry({required this.id, required this.type, required this.title, this.subtitle = '', this.date, this.amount = 0, this.done = false});
  final String id, type, title, subtitle;
  final DateTime? date;
  final int amount;
  final bool done;
  Map<String, dynamic> toJson() => {'id':id,'type':type,'title':title,'subtitle':subtitle,'date':date?.toIso8601String(),'amount':amount,'done':done};
  factory Entry.fromJson(Map<String,dynamic> j) => Entry(
    id:j['id'], type:j['type'], title:j['title'], subtitle:j['subtitle'] ?? '',
    date:j['date'] == null ? null : DateTime.tryParse(j['date']),
    amount:j['amount'] ?? 0, done:j['done'] ?? false);
}

class Store extends ChangeNotifier {
  static const key = 'hamrah_yar_entries_v1';
  final List<Entry> entries = [];
  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(key);
    if (raw != null) {
      try { entries.addAll((jsonDecode(raw) as List).map((e) => Entry.fromJson(e))); } catch (_) {}
    }
    notifyListeners();
  }
  Future<void> add(Entry e) async { entries.insert(0,e); await save(); }
  Future<void> remove(String id) async { entries.removeWhere((e)=>e.id==id); await save(); }
  Future<void> toggle(String id) async {
    final i=entries.indexWhere((e)=>e.id==id);
    if(i<0)return;
    final e=entries[i];
    entries[i]=Entry(id:e.id,type:e.type,title:e.title,subtitle:e.subtitle,date:e.date,amount:e.amount,done:!e.done);
    await save();
  }
  Future<void> save() async {
    final p=await SharedPreferences.getInstance();
    await p.setString(key,jsonEncode(entries.map((e)=>e.toJson()).toList()));
    notifyListeners();
  }
}

final store = Store();

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override State<HomeShell> createState()=>_HomeShellState();
}
class _HomeShellState extends State<HomeShell> {
  int tab=0;
  bool loading=true;
  @override void initState(){super.initState(); store.load().then((_){if(mounted)setState(()=>loading=false);});}
  final pages = const ['خانه','یادآورها','مدارک','پرداخت‌ها','وسایل'];
  @override Widget build(BuildContext context) {
    final bodies = [
      Dashboard(onGo:(i)=>setState(()=>tab=i)),
      EntryPage(type:'reminder',title:'یادآورها',icon:Icons.notifications_none_rounded),
      EntryPage(type:'document',title:'مدارک و گارانتی',icon:Icons.folder_open_rounded),
      EntryPage(type:'payment',title:'پرداخت‌ها و اقساط',icon:Icons.account_balance_wallet_outlined),
      EntryPage(type:'asset',title:'وسایل خانه و خودرو',icon:Icons.home_repair_service_outlined),
    ];
    return Scaffold(
      body: SafeArea(child: loading ? const Center(child:CircularProgressIndicator()) : bodies[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex:tab, onDestinationSelected:(v)=>setState(()=>tab=v),
        backgroundColor:Colors.white, indicatorColor:teal.withOpacity(.12),
        destinations: const [
          NavigationDestination(icon:Icon(Icons.grid_view_rounded),label:'خانه'),
          NavigationDestination(icon:Icon(Icons.notifications_none),label:'یادآورها'),
          NavigationDestination(icon:Icon(Icons.folder_outlined),label:'مدارک'),
          NavigationDestination(icon:Icon(Icons.payments_outlined),label:'پرداخت'),
          NavigationDestination(icon:Icon(Icons.home_repair_service_outlined),label:'وسایل'),
        ],
      ),
    );
  }
}

class Dashboard extends StatelessWidget {
  const Dashboard({super.key,required this.onGo});
  final ValueChanged<int> onGo;
  @override Widget build(BuildContext context) {
    final reminders=store.entries.where((e)=>e.type=='reminder'&&!e.done).toList();
    final docs=store.entries.where((e)=>e.type=='document').length;
    final payments=store.entries.where((e)=>e.type=='payment').toList();
    final total=payments.fold<int>(0,(s,e)=>s+e.amount);
    return AnimatedBuilder(animation:store,builder:(context,_)=>ListView(
      padding:const EdgeInsets.fromLTRB(20,14,20,28),
      children:[
        Row(children:[
          Container(width:46,height:46,decoration:BoxDecoration(color:teal,borderRadius:BorderRadius.circular(15)),child:const Icon(Icons.auto_awesome_rounded,color:Colors.white)),
          const SizedBox(width:12),
          const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text('همراه‌یار',style:TextStyle(fontSize:21,fontWeight:FontWeight.w900,color:ink)),
            Text('مدیریت ساده‌تر زندگی روزمره',style:TextStyle(color:Colors.black54,fontSize:12)),
          ])),
          IconButton(onPressed:()=>onGo(1),icon:const Icon(Icons.notifications_none_rounded,color:ink)),
        ]),
        const SizedBox(height:22),
        Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(
          gradient:const LinearGradient(colors:[Color(0xFF176F70),Color(0xFF22A394)],begin:Alignment.topRight,end:Alignment.bottomLeft),
          borderRadius:BorderRadius.circular(24)),
          child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text('امروز ${jalali(DateTime.now())}',style:const TextStyle(color:Colors.white70,fontSize:12)),
            const SizedBox(height:10),
            const Text('کارهای مهمت،\nهمیشه همراهت',style:TextStyle(color:Colors.white,fontSize:23,fontWeight:FontWeight.w800,height:1.4)),
            const SizedBox(height:14),
            Row(children:[
              const Icon(Icons.check_circle_outline,color:Colors.white70,size:17),
              const SizedBox(width:6),
              Text('${reminders.length} یادآور انجام‌نشده',style:const TextStyle(color:Colors.white,fontSize:13)),
            ])
          ])),
        const SizedBox(height:20),
        const Text('نمای کلی',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800,color:ink)),
        const SizedBox(height:12),
        Row(children:[
          Expanded(child:StatCard(icon:Icons.notifications_active_outlined,label:'یادآور فعال',value:'${reminders.length}',color:const Color(0xFF3978B8))),
          const SizedBox(width:10),
          Expanded(child:StatCard(icon:Icons.folder_copy_outlined,label:'مدرک ثبت‌شده',value:'$docs',color:const Color(0xFF9A6BC4))),
          const SizedBox(width:10),
          Expanded(child:StatCard(icon:Icons.payments_outlined,label:'پرداخت‌ها',value:'${payments.length}',color:const Color(0xFFCE8B37))),
        ]),
        const SizedBox(height:22),
        Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
          const Text('دسترسی سریع',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800,color:ink)),
          TextButton(onPressed:()=>onGo(1),child:const Text('همه موارد')),
        ]),
        GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,mainAxisSpacing:10,crossAxisSpacing:10,childAspectRatio:2.45,children:[
          QuickTile(icon:Icons.add_alert_rounded,title:'ثبت یادآور',color:teal,onTap:()=>showEntryDialog(context,'reminder')),
          QuickTile(icon:Icons.post_add_rounded,title:'ثبت مدرک',color:const Color(0xFF8B65B5),onTap:()=>showEntryDialog(context,'document')),
          QuickTile(icon:Icons.add_card_rounded,title:'ثبت پرداخت',color:const Color(0xFFC18A36),onTap:()=>showEntryDialog(context,'payment')),
          QuickTile(icon:Icons.devices_other_rounded,title:'ثبت وسیله',color:const Color(0xFF3978B8),onTap:()=>showEntryDialog(context,'asset')),
        ]),
        const SizedBox(height:22),
        const Text('نزدیک‌ترین یادآورها',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800,color:ink)),
        const SizedBox(height:8),
        if(reminders.isEmpty) const EmptyHint(text:'هنوز یادآوری ثبت نکرده‌ای. از دکمه ثبت یادآور شروع کن.'),
        ...reminders.take(3).map((e)=>EntryTile(entry:e,onDelete:()=>store.remove(e.id),onToggle:()=>store.toggle(e.id))),
        const SizedBox(height:10),
        if(total>0) Text('مجموع مبالغ ثبت‌شده: ${money(total)} تومان',style:const TextStyle(color:Colors.black54,fontSize:12)),
      ],
    ));
  }
}

class StatCard extends StatelessWidget {
  const StatCard({super.key,required this.icon,required this.label,required this.value,required this.color});
  final IconData icon; final String label,value; final Color color;
  @override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.symmetric(vertical:15,horizontal:8),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(18)),child:Column(children:[
    Icon(icon,color:color,size:21),const SizedBox(height:7),
    Text(value,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900,color:ink)),
    const SizedBox(height:3),Text(label,style:const TextStyle(fontSize:10,color:Colors.black54),textAlign:TextAlign.center),
  ]));
}
class QuickTile extends StatelessWidget {
  const QuickTile({super.key,required this.icon,required this.title,required this.color,required this.onTap});
  final IconData icon;final String title;final Color color;final VoidCallback onTap;
  @override Widget build(BuildContext context)=>Material(color:Colors.white,borderRadius:BorderRadius.circular(16),child:InkWell(borderRadius:BorderRadius.circular(16),onTap:onTap,child:Padding(padding:const EdgeInsets.symmetric(horizontal:13),child:Row(children:[
    CircleAvatar(radius:17,backgroundColor:color.withOpacity(.12),child:Icon(icon,color:color,size:19)),
    const SizedBox(width:9),Expanded(child:Text(title,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:12,color:ink))),
    const Icon(Icons.chevron_left,color:Colors.black38,size:18),
  ]))));
}

class EntryPage extends StatelessWidget {
  const EntryPage({super.key,required this.type,required this.title,required this.icon});
  final String type,title;final IconData icon;
  @override Widget build(BuildContext context)=>AnimatedBuilder(animation:store,builder:(context,_) {
    final items=store.entries.where((e)=>e.type==type).toList();
    return ListView(padding:const EdgeInsets.fromLTRB(20,16,20,28),children:[
      Row(children:[
        CircleAvatar(backgroundColor:teal.withOpacity(.12),child:Icon(icon,color:teal)),
        const SizedBox(width:12),Expanded(child:Text(title,style:const TextStyle(fontSize:21,fontWeight:FontWeight.w900,color:ink))),
        IconButton(onPressed:()=>showEntryDialog(context,type),style:IconButton.styleFrom(backgroundColor:teal),icon:const Icon(Icons.add,color:Colors.white)),
      ]),
      const SizedBox(height:8),
      Text(type=='reminder'?'کارها و قرارهای مهمت را فراموش نکن.':type=='document'?'اطلاعات مدارک و تاریخ گارانتی را یک‌جا نگه دار.':type=='payment'?'پرداخت‌ها و اقساطت را مرتب ثبت کن.':'مشخصات وسایل خانه و خودرو را نگهداری کن.',style:const TextStyle(color:Colors.black54,fontSize:13)),
      const SizedBox(height:18),
      if(items.isEmpty) EmptyHint(text:'هنوز موردی ثبت نشده است. برای شروع روی + بزن.'),
      ...items.map((e)=>EntryTile(entry:e,onDelete:()=>store.remove(e.id),onToggle:()=>store.toggle(e.id))),
    ]);
  });
}

class EntryTile extends StatelessWidget {
  const EntryTile({super.key,required this.entry,required this.onDelete,required this.onToggle});
  final Entry entry;final VoidCallback onDelete,onToggle;
  @override Widget build(BuildContext context) {
    final icon=entry.type=='reminder'?Icons.notifications_none:entry.type=='document'?Icons.description_outlined:entry.type=='payment'?Icons.payments_outlined:Icons.devices_other;
    return Container(margin:const EdgeInsets.only(bottom:9),padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(17)),child:Row(children:[
      if(entry.type=='reminder') Checkbox(value:entry.done,onChanged:(_)=>onToggle(),activeColor:teal,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(5)))
      else CircleAvatar(backgroundColor:teal.withOpacity(.1),child:Icon(icon,color:teal,size:19)),
      const SizedBox(width:9),
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(entry.title,style:TextStyle(fontWeight:FontWeight.w800,color:ink,decoration:entry.done?TextDecoration.lineThrough:null)),
        if(entry.subtitle.isNotEmpty) Padding(padding:const EdgeInsets.only(top:4),child:Text(entry.subtitle,style:const TextStyle(fontSize:12,color:Colors.black54))),
        if(entry.date!=null) Padding(padding:const EdgeInsets.only(top:5),child:Text('تاریخ: ${jalali(entry.date!)}',style:const TextStyle(fontSize:11,color:teal))),
        if(entry.amount>0) Padding(padding:const EdgeInsets.only(top:5),child:Text('${money(entry.amount)} تومان',style:const TextStyle(fontSize:12,color:teal,fontWeight:FontWeight.w700))),
      ])),
      IconButton(onPressed:()=>confirmDelete(context,onDelete),icon:const Icon(Icons.delete_outline,color:Colors.black38)),
    ]));
  }
}
class EmptyHint extends StatelessWidget {
  const EmptyHint({super.key,required this.text});final String text;
  @override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(17)),child:Column(children:[
    const Icon(Icons.inbox_outlined,size:30,color:Colors.black26),const SizedBox(height:8),
    Text(text,textAlign:TextAlign.center,style:const TextStyle(color:Colors.black54,fontSize:12)),
  ]));
}
Future<void> confirmDelete(BuildContext context,VoidCallback action) async {
  final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('حذف مورد'),content:const Text('از حذف این مورد مطمئنی؟'),actions:[
    TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('انصراف')),
    FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('حذف')),
  ]));
  if(ok==true)action();
}
String money(int n)=>n.toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'),(m)=>',');

Future<void> showEntryDialog(BuildContext context,String type) async {
  final title=TextEditingController(),subtitle=TextEditingController(),amount=TextEditingController();
  DateTime? date=DateTime.now().add(const Duration(days:1));
  final heading=type=='reminder'?'یادآور جدید':type=='document'?'مدرک یا گارانتی جدید':type=='payment'?'پرداخت یا قسط جدید':'وسیله جدید';
  final ok=await showModalBottomSheet<bool>(context:context,isScrollControlled:true,backgroundColor:Colors.transparent,builder:(ctx){
    return StatefulBuilder(builder:(ctx,setModal)=>Padding(padding:EdgeInsets.only(bottom:MediaQuery.of(ctx).viewInsets.bottom),child:Container(
      padding:const EdgeInsets.fromLTRB(20,14,20,24),decoration:const BoxDecoration(color:canvas,borderRadius:BorderRadius.vertical(top:Radius.circular(26))),
      child:SingleChildScrollView(child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        Center(child:Container(width:42,height:4,decoration:BoxDecoration(color:Colors.black12,borderRadius:BorderRadius.circular(8)))),
        const SizedBox(height:18),Text(heading,style:const TextStyle(fontSize:19,fontWeight:FontWeight.w900,color:ink)),
        const SizedBox(height:15),
        TextField(controller:title,decoration:const InputDecoration(labelText:'عنوان *',hintText:'مثلاً تمدید بیمه خودرو')),
        const SizedBox(height:10),
        TextField(controller:subtitle,maxLines:2,decoration:InputDecoration(labelText:type=='document'?'شماره یا توضیحات':type=='asset'?'مدل، شماره سریال یا توضیحات':'توضیحات (اختیاری)')),
        if(type=='payment') ...[const SizedBox(height:10),TextField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'مبلغ به تومان',hintText:'مثلاً 2500000'))],
        if(type!='asset') ...[
          const SizedBox(height:12),
          OutlinedButton.icon(onPressed:()async{
            final picked=await showDatePicker(context:ctx,initialDate:date??DateTime.now(),firstDate:DateTime(2020),lastDate:DateTime(2100),builder:(c,w)=>Directionality(textDirection:TextDirection.rtl,child:w!));
            if(picked!=null)setModal(()=>date=picked);
          },icon:const Icon(Icons.calendar_month_outlined),label:Text(date==null?'انتخاب تاریخ':'تاریخ: ${jalali(date!)}')),
        ],
        const SizedBox(height:18),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),style:FilledButton.styleFrom(backgroundColor:teal,padding:const EdgeInsets.symmetric(vertical:15)),child:const Text('ذخیره')),
      ]))));
  });
  if(ok==true && title.text.trim().isNotEmpty) {
    await store.add(Entry(id:DateTime.now().microsecondsSinceEpoch.toString(),type:type,title:title.text.trim(),subtitle:subtitle.text.trim(),date:date,amount:int.tryParse(amount.text.replaceAll(',',''))??0));
  }
}
